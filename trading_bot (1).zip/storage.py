import json
import os
import logging
from datetime import datetime, timezone, timedelta
from config import SIGNAL_COOLDOWN_HOURS

logger = logging.getLogger(__name__)
STORAGE_FILE = os.path.join(os.path.dirname(__file__), "signal_history.json")


def _load() -> dict:
    if not os.path.exists(STORAGE_FILE):
        return {}
    try:
        with open(STORAGE_FILE, "r") as f:
            return json.load(f)
    except Exception:
        return {}


def _save(data: dict) -> None:
    try:
        with open(STORAGE_FILE, "w") as f:
            json.dump(data, f, indent=2)
    except Exception as e:
        logger.error(f"Failed to save signal history: {e}")


def is_on_cooldown(symbol: str, signal_type: str) -> bool:
    data = _load()
    key = f"{symbol}_{signal_type}"
    if key not in data:
        return False
    last_sent = datetime.fromisoformat(data[key])
    cutoff = datetime.now(timezone.utc) - timedelta(hours=SIGNAL_COOLDOWN_HOURS)
    return last_sent > cutoff


def record_signal(symbol: str, signal_type: str) -> None:
    data = _load()
    key = f"{symbol}_{signal_type}"
    data[key] = datetime.now(timezone.utc).isoformat()
    _prune_old(data)
    _save(data)


def _prune_old(data: dict) -> None:
    cutoff = datetime.now(timezone.utc) - timedelta(hours=SIGNAL_COOLDOWN_HOURS * 4)
    keys_to_delete = []
    for key, ts_str in data.items():
        try:
            ts = datetime.fromisoformat(ts_str)
            if ts < cutoff:
                keys_to_delete.append(key)
        except Exception:
            keys_to_delete.append(key)
    for k in keys_to_delete:
        del data[k]


def get_signal_count() -> int:
    return len(_load())
