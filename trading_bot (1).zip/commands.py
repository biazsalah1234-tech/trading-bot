import logging
from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ParseMode

from exchange import get_klines, get_usdt_pairs
from indicators import add_all_indicators
from signals import generate_signal, _format_price

logger = logging.getLogger(__name__)

HELP_TEXT = (
    "🤖 <b>Trading Signal Bot — Commands</b>\n"
    "━━━━━━━━━━━━━━━━━━━━━\n"
    "/status <code>SYMBOL</code> — live indicators for a pair\n"
    "  e.g. <code>/status BTCUSDT</code>\n\n"
    "/pairs — list all monitored USDT pairs\n"
    "/help — show this message"
)


async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(
        "👋 <b>Trading Signal Bot is active!</b>\n\n"
        "I scan 66+ USDT pairs every 15 min and send buy/sell signals "
        "with TP1, TP2, TP3 and Stop Loss.\n\n"
        + HELP_TEXT,
        parse_mode=ParseMode.HTML,
    )


async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(HELP_TEXT, parse_mode=ParseMode.HTML)


async def cmd_pairs(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    msg = await update.message.reply_text("⏳ Fetching pair list...", parse_mode=ParseMode.HTML)
    pairs = get_usdt_pairs()
    if not pairs:
        await msg.edit_text("❌ Could not fetch pair list right now.")
        return
    chunks = [pairs[i:i + 6] for i in range(0, min(len(pairs), 60), 6)]
    rows = "  ".join(p for row in chunks for p in row)
    lines = []
    for i in range(0, min(len(pairs), 60), 6):
        lines.append("  ".join(f"<code>{p}</code>" for p in pairs[i:i + 6]))
    body = "\n".join(lines)
    text = (
        f"📋 <b>Monitored Pairs ({len(pairs)} total)</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━\n"
        f"{body}\n\n"
        "<i>Filtered: vol &gt; $1M/day · 1H timeframe</i>"
    )
    await msg.edit_text(text, parse_mode=ParseMode.HTML)


async def cmd_status(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    args = context.args
    if not args:
        await update.message.reply_text(
            "Usage: /status <code>SYMBOL</code>\nExample: <code>/status BTCUSDT</code>",
            parse_mode=ParseMode.HTML,
        )
        return

    symbol = args[0].upper().strip()
    if not symbol.endswith("USDT"):
        symbol = symbol + "USDT"

    msg = await update.message.reply_text(
        f"⏳ Fetching indicators for <b>{symbol}</b>...",
        parse_mode=ParseMode.HTML,
    )

    df = get_klines(symbol)
    if df is None or len(df) < 30:
        await msg.edit_text(
            f"❌ Could not fetch data for <code>{symbol}</code>. "
            "Check the symbol and try again.",
            parse_mode=ParseMode.HTML,
        )
        return

    df = add_all_indicators(df)
    last = df.iloc[-1]
    prev = df.iloc[-2]

    price = last["close"]
    ema_s = last["ema_short"]
    ema_l = last["ema_long"]
    rsi = last["rsi"]
    macd = last["macd"]
    macd_sig = last["macd_signal"]
    macd_hist = last["macd_hist"]
    adx = last["adx"]
    atr = last["atr"]

    ema_trend = "🟢 Bullish" if ema_s > ema_l else "🔴 Bearish"
    fresh_cross = (ema_s > ema_l) != (prev["ema_short"] > prev["ema_long"])
    cross_tag = " ⚡ <b>Fresh Cross!</b>" if fresh_cross else ""

    rsi_label = ""
    if rsi >= 70:
        rsi_label = " 🔴 Overbought"
    elif rsi <= 30:
        rsi_label = " 🟢 Oversold"
    elif rsi >= 60:
        rsi_label = " ⚠️ High"
    elif rsi <= 40:
        rsi_label = " ⚠️ Low"

    macd_trend = "🟢 Bullish" if macd > macd_sig else "🔴 Bearish"
    hist_dir = "↑" if macd_hist > prev["macd_hist"] else "↓"

    adx_label = ""
    if adx >= 30:
        adx_label = " (Strong 💪)"
    elif adx >= 20:
        adx_label = " (Moderate)"
    else:
        adx_label = " (Weak / Ranging)"

    sig = generate_signal(df, symbol)
    signal_line = ""
    if sig:
        arrow = "🟢 BUY signal detected!" if sig["type"] == "BUY" else "🔴 SELL signal detected!"
        signal_line = f"\n🚨 <b>{arrow}</b> (score {sig['score']}/10)\n"

    price_change = ((price - prev["close"]) / prev["close"]) * 100
    change_icon = "🟢" if price_change >= 0 else "🔴"

    text = (
        f"📊 <b>{symbol} — Live Status</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━\n"
        f"💰 Price: <b>${_format_price(price)}</b>  "
        f"{change_icon} {price_change:+.2f}% (1H)\n\n"
        f"📈 <b>EMA 9/21:</b>  {ema_trend}{cross_tag}\n"
        f"   EMA9:  <code>{_format_price(ema_s)}</code>\n"
        f"   EMA21: <code>{_format_price(ema_l)}</code>\n\n"
        f"📉 <b>RSI(14):</b>  <b>{rsi:.1f}</b>{rsi_label}\n\n"
        f"📊 <b>MACD(12,26,9):</b>  {macd_trend}\n"
        f"   Line:  <code>{macd:.6f}</code>\n"
        f"   Signal: <code>{macd_sig:.6f}</code>\n"
        f"   Hist:  <code>{macd_hist:.6f}</code> {hist_dir}\n\n"
        f"📐 <b>ADX(14):</b>  <b>{adx:.1f}</b>{adx_label}\n"
        f"📏 <b>ATR(14):</b>  <code>{_format_price(atr)}</code>\n"
        f"{signal_line}"
        f"\n<i>Timeframe: 1H · Source: KuCoin</i>"
    )

    await msg.edit_text(text, parse_mode=ParseMode.HTML)
