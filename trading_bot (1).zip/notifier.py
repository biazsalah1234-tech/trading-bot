import logging
from telegram import Bot
from telegram.constants import ParseMode
from config import TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID

logger = logging.getLogger(__name__)

_bot: Bot | None = None


def get_bot() -> Bot:
    global _bot
    if _bot is None:
        _bot = Bot(token=TELEGRAM_BOT_TOKEN)
    return _bot


async def send_message(text: str) -> bool:
    try:
        bot = get_bot()
        await bot.send_message(
            chat_id=TELEGRAM_CHAT_ID,
            text=text,
            parse_mode=ParseMode.HTML,
            disable_web_page_preview=True
        )
        return True
    except Exception as e:
        logger.error(f"Failed to send Telegram message: {e}")
        return False


async def send_signal(signal_msg: str) -> bool:
    return await send_message(signal_msg)


async def send_startup_message(pair_count: int, exchange: str = "KuCoin") -> None:
    msg = (
        "🤖 <b>Trading Signal Bot Started</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━\n"
        f"📊 Monitoring <b>{pair_count}</b> USDT pairs (vol &gt; $1M/day)\n"
        "🔍 Indicators: EMA 9/21 · RSI(14) · MACD · ADX\n"
        "⏱ Scan interval: every 15 minutes\n"
        f"📡 Data source: {exchange} Public API\n\n"
        "Signals will be sent with TP1, TP2, TP3 &amp; Stop Loss."
    )
    await send_message(msg)


async def send_scan_summary(scanned: int, signals: int) -> None:
    from datetime import datetime, timezone
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    msg = (
        f"🔄 <b>Scan Complete</b> — {now}\n"
        f"Checked <b>{scanned}</b> pairs → <b>{signals}</b> signal(s) found"
    )
    await send_message(msg)
