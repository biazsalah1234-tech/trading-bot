import pandas as pd
import numpy as np
from typing import Optional
from config import (
    MIN_ADX, RSI_BUY_MIN, RSI_BUY_MAX, RSI_SELL_MIN, RSI_SELL_MAX,
    TP1_ATR_MULT, TP2_ATR_MULT, TP3_ATR_MULT, SL_ATR_MULT
)


def _format_price(price: float) -> str:
    if price >= 1000:
        return f"{price:,.2f}"
    elif price >= 1:
        return f"{price:.4f}"
    elif price >= 0.01:
        return f"{price:.5f}"
    else:
        return f"{price:.8f}"


def _pct(entry: float, target: float) -> str:
    pct = ((target - entry) / entry) * 100
    sign = "+" if pct >= 0 else ""
    return f"{sign}{pct:.2f}%"


def generate_signal(df: pd.DataFrame, symbol: str) -> Optional[dict]:
    if len(df) < 50:
        return None

    last = df.iloc[-1]
    prev = df.iloc[-2]

    ema_short = last["ema_short"]
    ema_long = last["ema_long"]
    prev_ema_short = prev["ema_short"]
    prev_ema_long = prev["ema_long"]

    rsi = last["rsi"]
    macd_hist = last["macd_hist"]
    prev_macd_hist = prev["macd_hist"]
    macd_line = last["macd"]
    macd_signal = last["macd_signal"]
    adx = last["adx"]
    atr = last["atr"]
    entry = last["close"]

    if atr <= 0 or np.isnan(atr):
        return None

    score = 0
    signal_type = None

    ema_bullish = ema_short > ema_long
    ema_bearish = ema_short < ema_long
    fresh_bullish_cross = (ema_short > ema_long) and (prev_ema_short <= prev_ema_long)
    fresh_bearish_cross = (ema_short < ema_long) and (prev_ema_short >= prev_ema_long)

    buy_score = 0
    sell_score = 0

    if fresh_bullish_cross:
        buy_score += 3
    elif ema_bullish:
        buy_score += 2

    if fresh_bearish_cross:
        sell_score += 3
    elif ema_bearish:
        sell_score += 2

    if RSI_BUY_MIN <= rsi <= RSI_BUY_MAX:
        buy_score += 2
    elif rsi < RSI_BUY_MIN:
        buy_score += 1

    if RSI_SELL_MIN <= rsi <= RSI_SELL_MAX:
        sell_score += 2
    elif rsi > 70:
        sell_score += 1

    if macd_line > macd_signal:
        buy_score += 2
    if macd_hist > 0 and macd_hist > prev_macd_hist:
        buy_score += 1

    if macd_line < macd_signal:
        sell_score += 2
    if macd_hist < 0 and macd_hist < prev_macd_hist:
        sell_score += 1

    if adx >= 25:
        buy_score += 2
        sell_score += 2
    elif adx >= MIN_ADX:
        buy_score += 1
        sell_score += 1

    if buy_score >= 7 and buy_score > sell_score:
        signal_type = "BUY"
        score = buy_score
    elif sell_score >= 7 and sell_score > buy_score:
        signal_type = "SELL"
        score = sell_score
    else:
        return None

    if signal_type == "BUY":
        tp1 = entry + TP1_ATR_MULT * atr
        tp2 = entry + TP2_ATR_MULT * atr
        tp3 = entry + TP3_ATR_MULT * atr
        sl = entry - SL_ATR_MULT * atr
    else:
        tp1 = entry - TP1_ATR_MULT * atr
        tp2 = entry - TP2_ATR_MULT * atr
        tp3 = entry - TP3_ATR_MULT * atr
        sl = entry + SL_ATR_MULT * atr

    risk = abs(entry - sl)
    reward_tp2 = abs(tp2 - entry)
    rr_ratio = round(reward_tp2 / risk, 2) if risk > 0 else 0

    return {
        "symbol": symbol,
        "type": signal_type,
        "entry": entry,
        "tp1": tp1,
        "tp2": tp2,
        "tp3": tp3,
        "sl": sl,
        "rsi": round(rsi, 2),
        "macd_hist": round(macd_hist, 6),
        "adx": round(adx, 2),
        "ema_short": round(ema_short, 6),
        "ema_long": round(ema_long, 6),
        "atr": round(atr, 6),
        "score": score,
        "rr_ratio": rr_ratio,
        "fresh_cross": fresh_bullish_cross or fresh_bearish_cross,
    }


def format_signal_message(sig: dict) -> str:
    s = sig["type"]
    symbol = sig["symbol"]
    entry = sig["entry"]

    emoji = "🟢" if s == "BUY" else "🔴"
    action = "BUY" if s == "BUY" else "SELL"
    ema_label = "Bullish ✅" if s == "BUY" else "Bearish ⚠️"
    cross_tag = " 🔀 Fresh Cross!" if sig["fresh_cross"] else ""

    rsi_val = sig["rsi"]
    rsi_label = ""
    if rsi_val < 30:
        rsi_label = " (Oversold)"
    elif rsi_val > 70:
        rsi_label = " (Overbought)"

    tp1_pct = _pct(entry, sig["tp1"])
    tp2_pct = _pct(entry, sig["tp2"])
    tp3_pct = _pct(entry, sig["tp3"])
    sl_pct = _pct(entry, sig["sl"])

    msg = (
        f"{emoji} <b>{action} SIGNAL — {symbol}</b>{cross_tag}\n"
        f"━━━━━━━━━━━━━━━━━━━━━\n"
        f"💰 <b>Entry:</b>  ${_format_price(entry)}\n\n"
        f"🎯 <b>TP1:</b>  ${_format_price(sig['tp1'])}  <i>({tp1_pct})</i>\n"
        f"🎯 <b>TP2:</b>  ${_format_price(sig['tp2'])}  <i>({tp2_pct})</i>\n"
        f"🎯 <b>TP3:</b>  ${_format_price(sig['tp3'])}  <i>({tp3_pct})</i>\n"
        f"🛑 <b>Stop Loss:</b>  ${_format_price(sig['sl'])}  <i>({sl_pct})</i>\n\n"
        f"📊 <b>Indicators:</b>\n"
        f"  • EMA9/21 ({sig['ema_short']:.4f} / {sig['ema_long']:.4f}): {ema_label}\n"
        f"  • RSI(14): <b>{rsi_val}</b>{rsi_label}\n"
        f"  • MACD Hist: <b>{sig['macd_hist']}</b>\n"
        f"  • ADX: <b>{sig['adx']}</b> {'(Strong Trend 💪)' if sig['adx'] >= 25 else '(Moderate)'}\n\n"
        f"⚖️ Risk/Reward: <b>1:{sig['rr_ratio']}</b>  |  Signal Score: <b>{sig['score']}/10</b>\n"
        f"📡 Timeframe: 1H  |  Binance Spot"
    )
    return msg


