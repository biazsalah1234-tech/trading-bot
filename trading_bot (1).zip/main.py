import asyncio
import logging
import sys
import os

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.interval import IntervalTrigger
from telegram.ext import Application, CommandHandler

sys.path.insert(0, os.path.dirname(__file__))

from config import TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, SCAN_INTERVAL_MINUTES
from exchange import get_usdt_pairs, _probe_exchange
from notifier import send_startup_message, send_message
from scanner import run_scan
from commands import cmd_start, cmd_help, cmd_pairs, cmd_status

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("apscheduler").setLevel(logging.WARNING)
logger = logging.getLogger(__name__)

_scan_lock = asyncio.Lock()


async def safe_scan() -> None:
    if _scan_lock.locked():
        logger.warning("Previous scan still running — skipping this cycle")
        return
    async with _scan_lock:
        try:
            await run_scan()
        except Exception as e:
            logger.error(f"Scan failed: {e}", exc_info=True)
            try:
                await send_message(f"⚠️ <b>Scan Error</b>\n<code>{str(e)[:200]}</code>")
            except Exception:
                pass


async def main() -> None:
    logger.info("=" * 60)
    logger.info("  Binance USDT Trading Signal Bot")
    logger.info("=" * 60)

    if not TELEGRAM_BOT_TOKEN:
        logger.error("TELEGRAM_BOT_TOKEN is not set — exiting")
        sys.exit(1)
    if not TELEGRAM_CHAT_ID:
        logger.error("TELEGRAM_CHAT_ID is not set — exiting")
        sys.exit(1)

    # ── Build Telegram Application ──────────────────────────────
    app = Application.builder().token(TELEGRAM_BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("help", cmd_help))
    app.add_handler(CommandHandler("pairs", cmd_pairs))
    app.add_handler(CommandHandler("status", cmd_status))

    await app.initialize()
    await app.start()
    await app.updater.start_polling(drop_pending_updates=True)
    logger.info("Telegram command polling started (/start /help /pairs /status)")

    # ── Fetch pairs & notify ────────────────────────────────────
    logger.info("Fetching initial pair list...")
    pairs = get_usdt_pairs()
    logger.info(f"Found {len(pairs)} qualifying USDT pairs")

    exchange_name = _probe_exchange().upper()
    try:
        await send_startup_message(len(pairs), exchange=exchange_name)
    except Exception as e:
        logger.warning(f"Could not send startup message: {e}")

    # ── Scheduler ───────────────────────────────────────────────
    scheduler = AsyncIOScheduler(timezone="UTC")
    scheduler.add_job(
        safe_scan,
        trigger=IntervalTrigger(minutes=SCAN_INTERVAL_MINUTES),
        id="market_scan",
        name="Market Scanner",
        replace_existing=True,
        max_instances=1,
    )
    scheduler.start()
    logger.info(f"Scheduler started — scanning every {SCAN_INTERVAL_MINUTES} minutes")

    # ── Initial scan ─────────────────────────────────────────────
    logger.info("Running initial scan now...")
    await safe_scan()

    # ── Keep alive ───────────────────────────────────────────────
    try:
        while True:
            await asyncio.sleep(60)
    except (KeyboardInterrupt, SystemExit):
        logger.info("Shutting down...")
        scheduler.shutdown(wait=False)
        await app.updater.stop()
        await app.stop()
        await app.shutdown()


if __name__ == "__main__":
    asyncio.run(main())
