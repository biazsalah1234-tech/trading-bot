import requests
import pandas as pd
import logging
from typing import Optional
from config import MIN_VOLUME_USDT, TIMEFRAME, CANDLE_LIMIT

logger = logging.getLogger(__name__)

KUCOIN_BASE = "https://api.kucoin.com"
OKX_BASE = "https://www.okx.com"

# KuCoin interval map: config value -> KuCoin string
KUCOIN_INTERVAL_MAP = {
    "1m": "1min", "3m": "3min", "5m": "5min", "15m": "15min",
    "30m": "30min", "1h": "1hour", "2h": "2hour", "4h": "4hour",
    "6h": "6hour", "12h": "12hour", "1d": "1day",
}

# OKX interval map
OKX_INTERVAL_MAP = {
    "1m": "1m", "3m": "3m", "5m": "5m", "15m": "15m", "30m": "30m",
    "1h": "1H", "2h": "2H", "4h": "4H", "6h": "6H", "12h": "12H", "1d": "1D",
}

_active_exchange: str | None = None  # "kucoin" | "okx"


def _probe_exchange() -> str:
    global _active_exchange
    if _active_exchange:
        return _active_exchange
    try:
        r = requests.get(f"{KUCOIN_BASE}/api/v1/timestamp", timeout=6)
        if r.status_code == 200:
            logger.info("Using KuCoin API (primary)")
            _active_exchange = "kucoin"
            return _active_exchange
    except Exception:
        pass
    try:
        r = requests.get(f"{OKX_BASE}/api/v5/public/time", timeout=6)
        if r.status_code == 200:
            logger.info("Using OKX API (fallback)")
            _active_exchange = "okx"
            return _active_exchange
    except Exception:
        pass
    logger.warning("No exchange reachable — defaulting to KuCoin")
    _active_exchange = "kucoin"
    return _active_exchange


# ── KuCoin ─────────────────────────────────────────────────────────────────

def _kucoin_get_usdt_pairs() -> list[str]:
    resp = requests.get(f"{KUCOIN_BASE}/api/v1/market/allTickers", timeout=15)
    resp.raise_for_status()
    data = resp.json().get("data", {}).get("ticker", [])
    pairs = []
    for t in data:
        symbol = t.get("symbol", "")
        if not symbol.endswith("-USDT"):
            continue
        try:
            vol_value = float(t.get("volValue", 0) or 0)
        except (ValueError, TypeError):
            continue
        if vol_value >= MIN_VOLUME_USDT:
            pairs.append(symbol.replace("-", ""))  # store as BTCUSDT internally
    return sorted(pairs)


def _kucoin_get_klines(symbol: str, interval: str, limit: int) -> Optional[pd.DataFrame]:
    import time as _time
    kc_symbol = symbol[:-4] + "-" + symbol[-4:]  # BTCUSDT -> BTC-USDT
    kc_interval = KUCOIN_INTERVAL_MAP.get(interval, "1hour")
    end_ts = int(_time.time())
    # KuCoin returns max 1500 candles; each 1h candle = 3600s
    start_ts = end_ts - limit * 3600
    params = {
        "symbol": kc_symbol,
        "type": kc_interval,
        "startAt": start_ts,
        "endAt": end_ts,
    }
    resp = requests.get(f"{KUCOIN_BASE}/api/v1/market/candles", params=params, timeout=10)
    resp.raise_for_status()
    raw = resp.json().get("data", [])
    if not raw:
        return None
    # KuCoin returns newest first: [timestamp, open, close, high, low, volume, turnover]
    df = pd.DataFrame(raw, columns=["open_time", "open", "close", "high", "low", "volume", "quote_vol"])
    for col in ["open", "high", "low", "close", "volume", "quote_vol"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df["open_time"] = pd.to_datetime(pd.to_numeric(df["open_time"]), unit="s", utc=True)
    df = df.sort_values("open_time").reset_index(drop=True)
    return df[["open_time", "open", "high", "low", "close", "volume", "quote_vol"]].copy()


# ── OKX ────────────────────────────────────────────────────────────────────

def _okx_get_usdt_pairs() -> list[str]:
    resp = requests.get(f"{OKX_BASE}/api/v5/market/tickers",
                        params={"instType": "SPOT"}, timeout=15)
    resp.raise_for_status()
    data = resp.json().get("data", [])
    pairs = []
    for t in data:
        inst_id = t.get("instId", "")
        if not inst_id.endswith("-USDT"):
            continue
        try:
            vol = float(t.get("volCcy24h", 0) or t.get("vol24h", 0) or 0)
        except (ValueError, TypeError):
            continue
        if vol >= MIN_VOLUME_USDT:
            pairs.append(inst_id.replace("-", ""))
    return sorted(pairs)


def _okx_get_klines(symbol: str, interval: str, limit: int) -> Optional[pd.DataFrame]:
    okx_symbol = symbol[:-4] + "-" + symbol[-4:]  # BTCUSDT -> BTC-USDT
    okx_bar = OKX_INTERVAL_MAP.get(interval, "1H")
    params = {"instId": okx_symbol, "bar": okx_bar, "limit": min(limit, 300)}
    resp = requests.get(f"{OKX_BASE}/api/v5/market/candles", params=params, timeout=10)
    resp.raise_for_status()
    raw = resp.json().get("data", [])
    if not raw:
        return None
    # OKX: [ts, o, h, l, c, vol, volCcy, volCcyQuote, confirm] newest first
    df = pd.DataFrame(raw, columns=["open_time", "open", "high", "low", "close",
                                     "volume", "vol_ccy", "quote_vol", "confirm"])
    for col in ["open", "high", "low", "close", "volume", "quote_vol"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df["open_time"] = pd.to_datetime(pd.to_numeric(df["open_time"]), unit="ms", utc=True)
    df = df.sort_values("open_time").reset_index(drop=True)
    return df[["open_time", "open", "high", "low", "close", "volume", "quote_vol"]].copy()


# ── Public API ─────────────────────────────────────────────────────────────

def get_usdt_pairs() -> list[str]:
    exchange = _probe_exchange()
    try:
        if exchange == "kucoin":
            pairs = _kucoin_get_usdt_pairs()
        else:
            pairs = _okx_get_usdt_pairs()
        logger.info(f"[{exchange}] {len(pairs)} USDT pairs with vol >= ${MIN_VOLUME_USDT:,.0f}")
        return pairs
    except Exception as e:
        logger.error(f"[{exchange}] Failed to fetch pairs: {e}")
        return []


def get_klines(symbol: str, interval: str = TIMEFRAME, limit: int = CANDLE_LIMIT) -> Optional[pd.DataFrame]:
    exchange = _probe_exchange()
    try:
        if exchange == "kucoin":
            return _kucoin_get_klines(symbol, interval, limit)
        else:
            return _okx_get_klines(symbol, interval, limit)
    except Exception as e:
        logger.debug(f"[{exchange}] klines failed for {symbol}: {e}")
        return None
