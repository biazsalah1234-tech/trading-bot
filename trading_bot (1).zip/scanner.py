import asyncio
import logging
from datetime import datetime, timezone

from exchange import get_usdt_pairs, get_klines
from indicators import add_all_indicators
from signals import generate_signal, format_signal_message
from notifier import send_signal, send_scan_summary
from storage import is_on_cooldown, record_signal

logger = logging.getLogger(__name__)

BATCH_SIZE = 10
BATCH_DELAY = 0.5


async def scan_pair(symbol: str) -> dict | None:
    df = await asyncio.get_event_loop().run_in_executor(None, get_klines, symbol)
    if df is None or len(df) < 50:
        return None

    df = add_all_indicators(df)
    sig = generate_signal(df, symbol)
    return sig


async def run_scan() -> None:
    start = datetime.now(timezone.utc)
    logger.info(f"Starting market scan at {start.strftime('%Y-%m-%d %H:%M UTC')}")

    pairs = await asyncio.get_event_loop().run_in_executor(None, get_usdt_pairs)
    if not pairs:
        logger.warning("No pairs returned from exchange — skipping scan")
        return

    logger.info(f"Scanning {len(pairs)} pairs...")

    signals_sent = 0
    scanned = 0

    for i in range(0, len(pairs), BATCH_SIZE):
        batch = pairs[i:i + BATCH_SIZE]
        tasks = [scan_pair(symbol) for symbol in batch]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        for symbol, result in zip(batch, results):
            scanned += 1
            if isinstance(result, Exception):
                logger.debug(f"Error scanning {symbol}: {result}")
                continue
            if result is None:
                continue

            sig = result
            if is_on_cooldown(symbol, sig["type"]):
                logger.debug(f"Skipping {symbol} {sig['type']} — on cooldown")
                continue

            msg = format_signal_message(sig)
            sent = await send_signal(msg)
            if sent:
                record_signal(symbol, sig["type"])
                signals_sent += 1
                logger.info(
                    f"Signal sent: {sig['type']} {symbol} | "
                    f"Entry={sig['entry']:.4f} | ADX={sig['adx']} | "
                    f"RSI={sig['rsi']} | Score={sig['score']}"
                )

        if i + BATCH_SIZE < len(pairs):
            await asyncio.sleep(BATCH_DELAY)

    elapsed = (datetime.now(timezone.utc) - start).total_seconds()
    logger.info(f"Scan done: {scanned} pairs checked, {signals_sent} signals sent ({elapsed:.1f}s)")

    await send_scan_summary(scanned, signals_sent)
